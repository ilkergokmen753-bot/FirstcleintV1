package de.firstclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class FirstClientScreen extends Screen {
    private boolean crown, wings, particles;
    public FirstClientScreen() { super(Component.literal("First Client")); }

    @Override protected void init() {
        int x = width / 2 - 105, y = height / 2 - 55;
        addRenderableWidget(toggle("Krone", () -> crown, v -> crown = v, x, y));
        addRenderableWidget(toggle("Flügel", () -> wings, v -> wings = v, x, y + 27));
        addRenderableWidget(toggle("Partikel", () -> particles, v -> particles = v, x, y + 54));
        addRenderableWidget(Button.builder(Component.literal("Schließen"), b -> onClose())
                .bounds(x, y + 91, 210, 20).build());
    }

    private Button toggle(String name, java.util.function.BooleanSupplier get,
                          java.util.function.Consumer<Boolean> set, int x, int y) {
        Button button = Button.builder(label(name, get.getAsBoolean()), b -> {
            boolean next = !get.getAsBoolean();
            set.accept(next);
            b.setMessage(label(name, next));
        }).bounds(x, y, 210, 20).build();
        return button;
    }

    private static Component label(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "AN" : "AUS"));
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(font, Component.literal("FIRST CLIENT"), width / 2, height / 2 - 82, 0xFFB45CFF);
        g.drawCenteredString(font, Component.literal("Minecraft 1.21.11  •  kostenlose Cosmetics"), width / 2,
                height / 2 + 65, 0xFFE2D7FF);
    }
    @Override public boolean isPauseScreen() { return false; }
}
