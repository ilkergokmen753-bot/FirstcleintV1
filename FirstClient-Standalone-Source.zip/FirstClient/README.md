# First Client – Standalone-Mod (0.1.0)

Minecraft Java 1.21.11 / Fabric / Java 21.

## Enthalten
- eigenständige Fabric-Client-Mod
- Menü per **Right Shift**
- Cosmetic-Auswahl-Demo: Krone, Flügel, Partikel
- unabhängig vom First-Client-Launcher nutzbar

**Hinweis:** Die Cosmetic-Schalter sind in dieser ersten Version nur eine Menü-Demo. Sie speichern noch keine Auswahl und rendern noch keine 3D-Cosmetics. Microsoft-Anmeldung und Serverliste nutzt du sicher über den offiziellen Minecraft-Launcher und Minecrafts Mehrspieler-Menü. Diese Mod fragt niemals ein Microsoft-Passwort ab.

## Build
Voraussetzungen: JDK 21, Gradle, Fabric Loader und Fabric API für 1.21.11.

Im Projektordner:
```bash
gradle build
```
Ausgabe:
`build/libs/firstclient-0.1.0.jar`

## Installation
1. Fabric für Minecraft 1.21.11 installieren und einmal starten.
2. Die gebaute `firstclient-0.1.0.jar` in den Minecraft-Ordner `mods` legen.
3. Minecraft mit dem Fabric-Profil starten.
4. Im Spiel **Right Shift** drücken.

## Weiterer Ausbau
Persistente Cosmetic-Auswahl, echte Cosmetic-Render-Komponenten, FPS/CPS/Keystrokes-HUD und eigenes Logo-Asset.
